
jQuery(document).ready(function($) {
    $("#competition, #round").change(function() {
        var competition = $("#competition").val();
        var round = $("#round").val();

        $.ajax({
            url: sportslitescreenreadertext.ajaxurl,
            type: 'POST',
            data: {
                action: 'filter_results',
                competition: competition,
                round: round
            },
            success: function(response) {
                $("#results-container").html(response); // Update only the results container
            },
            error: function() {
                alert('An error occurred while loading the results.');
            }
        });
    });
});
