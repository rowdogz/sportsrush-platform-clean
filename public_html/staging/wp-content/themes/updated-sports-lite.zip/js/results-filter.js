
jQuery(document).ready(function($) {
    $('#filter-results').on('click', function() {
        let competition = $('#competition').val();
        let round = $('#round').val();

        $.ajax({
            url: resultsAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'filter_results',
                competition: competition,
                round: round
            },
            success: function(response) {
                $('#results-content').html(response);
            },
            error: function() {
                $('#results-content').html('<p>An error occurred while fetching the results.</p>');
            }
        });
    });
});
