<?php

    session_start();
    require_once('includes/hybridauth/src/autoload.php');

    if(isset($_SESSION["user_email"]))
    {
        header("location:https://www.sportsrush.co.uk/");
    }

    use Hybridauth\Exception\Exception;
    use Hybridauth\Hybridauth;
    use Hybridauth\HttpClient;
    
    if($_GET["request"] == "google" || $_GET["request"] == "facebook")
    {
        $provider = $_GET["request"];
        $config = [
            'callback' => "https://tijuana.doctor/auth/callback.php?request=$provider",
            'providers' => [
                'Google' => [
                    'enabled' => true,
                    'keys' => [
                        'id' => '933420808713-uihcab04jogontm5qnml8tuno23k92vd.apps.googleusercontent.com',
                        'secret' => 'NHarD21LVg2nasRUrCsSD0wT',
                    ]
                ],
                'Facebook' => [
                    'enabled' => true,
                    'keys' => [
                        'id' => '897292717674577',
                        'secret' => 'c889f006af1cfb835381df6454ba44f3',
                    ]
                ]
            ]
        ];
    }
    
    else
    {
        HttpClient\Util::redirect('https://sportsrush.co.uk');
    }

    try
    {
    
        $hybridauth = new Hybridauth($config);

        $hybridauth->authenticate(ucfirst($provider));

        $adapters = $hybridauth->getConnectedAdapters();

        $userInfo = $adapters[ucfirst($provider)]->getUserProfile();
        
        // ******************************************************
        //  Now that we have data on the user,
        // this is where you would store it in YOUR database
        // ******************************************************

        $email = $userInfo->email;
        // $fullname = $userInfo->firstName." ".$userInfo->lastName;
        $user_avatar = $userInfo->photoURL;
        // $username = explode("@", $userInfo->email)[0];
        // $phone = $userInfo->phone;

        $_SESSION["admin_email"] = $email;
        $_SESSION['admin_pic'] = $user_avatar;
        
        /**
        * Redirects user to home page (i.e., index.php in our case)
        */
        HttpClient\Util::redirect('https://www.sportsrush.co.uk');

    }
    catch (Exception $e)
    {
        echo $e->getMessage();
    }
?>